import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from "@angular/router";

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ContentComponent } from "./components/content/content.component";

import { FormComponent } from './components/form/form.component';
import { FormsModule } from "@angular/forms";
import { SellingComponent } from './components/selling/selling.component';
import { CocSellingComponent } from './components/coc-selling/coc-selling.component';
import { CrSellingComponent } from './components/cr-selling/cr-selling.component';
import { BsSellingComponent } from './components/bs-selling/bs-selling.component';
import { SigninComponent } from './components/signin/signin.component';
import { AboutComponent } from './components/about/about.component';

const appRoutes: Routes = [
  {path: '', component: ContentComponent },
  {path: 'selling', component: SellingComponent},
  {path: 'selling/cocSelling', component: CocSellingComponent},
  {path: 'selling/crSelling', component: CrSellingComponent},
  {path: 'selling/bsSelling', component: BsSellingComponent},
  {path: 'about', component: AboutComponent},
  {path: 'signin', component: SigninComponent}
]

@NgModule({
  declarations: [
    AppComponent,
    ContentComponent,
    FormComponent,
    SellingComponent,
    CocSellingComponent,
    CrSellingComponent,
    BsSellingComponent,
    SigninComponent,
    AboutComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
