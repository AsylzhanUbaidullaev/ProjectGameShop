import { Injectable } from "@angular/core";

@Injectable({provideIn: 'root'})
export class GamesService {
  constructor(parameters) {
    
  }
}
