import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-coc-selling',
  templateUrl: './coc-selling.component.html',
  styleUrls: ['./coc-selling.component.css']
})
export class CocSellingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
