import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-selling-account',
  templateUrl: './selling-account.component.html',
  styleUrls: ['./selling-account.component.css']
})
export class SellingAccountComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
