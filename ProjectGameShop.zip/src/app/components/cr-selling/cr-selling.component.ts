import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cr-selling',
  templateUrl: './cr-selling.component.html',
  styleUrls: ['./cr-selling.component.css']
})
export class CrSellingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
