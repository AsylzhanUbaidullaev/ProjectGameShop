import { Component, OnInit } from '@angular/core';
import {ComponentCanDeactivate} from '../../guards/deactivate-selling.guard';
import {Observable} from 'rxjs';

@Component({
  selector: 'app-cr-selling',
  templateUrl: './cr-selling.component.html',
  styleUrls: ['./cr-selling.component.css']
})
export class CrSellingComponent implements OnInit, ComponentCanDeactivate {

  saved = false;
  save(){
    this.saved = true;
  }

  canDeactivate(): boolean | Observable<boolean>{

    if (!this.saved){
      return confirm('Tap OK, if you dont want to put up account for sale');
    }
    else{
      return true;
    }
  }

  constructor() { }

  ngOnInit(): void {
  }

}
