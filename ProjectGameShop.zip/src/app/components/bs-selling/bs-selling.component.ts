import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bs-selling',
  templateUrl: './bs-selling.component.html',
  styleUrls: ['./bs-selling.component.css']
})
export class BsSellingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
