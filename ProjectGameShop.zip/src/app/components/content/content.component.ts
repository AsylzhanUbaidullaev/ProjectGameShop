import { Component, OnInit } from '@angular/core';

export interface Game {
  name: string
}

@Component({
  selector: 'app-content',
  templateUrl: './content.component.html',
  styleUrls: ['./content.component.css']
})
export class ContentComponent implements OnInit {
  game1 = "Clash of clans"
  game2 = "Clash Royale"
  game3 = "Brawl Stars"

  toggle = true

  // games=[/Clash of clans, /Clash Royale, /Brawl Stars]

  imgUrl: string = 'https://lh3.googleusercontent.com/N7kXofWjMoOrFS-OnfiackBTfnMeuWJAJTDjtt8fKbsmqN39G7jO7ZccQ8VTxvKn_PZl'

  constructor() { }

  addGame = 'Add Game'

  ngOnInit(): void {
    setTimeout(() => {
      this.imgUrl = 'https://lh3.googleusercontent.com/fE7lm5NTSU50vCQUa3H4Wh2ZzmlNJgRODd7HImH7Spg-SQ4O7_lKV4wHYzBEWd21QDw'
      //this.imgUrl = 'https://vignette.wikia.nocookie.net/brawlstars/images/8/86/Brawl_Stars_Slider.jpg/revision/latest/window-crop/width/400/x-offset/0/y-offset/0/window-width/1280/window-height/720?cb=20190202175856&path-prefix=ru'
    }, 5000);
  }

  // games: Game[] = [
  //   {name: 'Clash of clans'},
  //   {name: 'Clash Royale'},
  //   {name: 'Brawl Stars'}
  // ]
  // addGame(game: Game) {
  //   this.game.push(game)
  // }

  toggleGames() {
    this.toggle = !this.toggle
  }
}
