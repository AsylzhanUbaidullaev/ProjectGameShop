import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-brawlstars',
  templateUrl: './brawlstars.component.html',
  styleUrls: ['./brawlstars.component.css']
})
export class BrawlstarsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
