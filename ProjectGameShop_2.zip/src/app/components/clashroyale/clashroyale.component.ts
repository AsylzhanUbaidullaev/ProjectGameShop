import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-clashroyale',
  templateUrl: './clashroyale.component.html',
  styleUrls: ['./clashroyale.component.css']
})
export class ClashroyaleComponent implements OnInit {

  img1=""
  img2=""
  img3=""
  constructor() { }

  ngOnInit(): void {
  }

}
