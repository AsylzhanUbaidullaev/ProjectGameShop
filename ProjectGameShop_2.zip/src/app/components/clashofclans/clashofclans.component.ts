import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-clashofclans',
  templateUrl: './clashofclans.component.html',
  styleUrls: ['./clashofclans.component.css']
})
export class ClashofclansComponent implements OnInit {


  constructor() { }

  ngOnInit(): void {
  }

}
