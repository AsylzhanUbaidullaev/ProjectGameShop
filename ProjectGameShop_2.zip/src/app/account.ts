export class Account {
  th: string;
  price: string;
  image: string;
}
